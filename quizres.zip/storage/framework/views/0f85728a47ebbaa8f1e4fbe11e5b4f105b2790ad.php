

<?php $__env->startSection('content'); ?>

<h1 class='text-center'>Quiz:</h1>
<div class='d-flex justify-content-md-center mt-4'>
    <div class='mr-4'>
        <p>Название Quiz-а: </p>
        <p>Код Quiz-а: </p>
        <p>Программа: </p>
        <p>Unit: </p>
    </div>
    <div class='ml-4'>
        <p><?php echo e($quiz->quiz_name); ?></p>
        <p><?php echo e($quiz->quiz_code); ?></p>
        <p><?php echo e($quiz->Program); ?></p>
        <p><?php echo e($quiz->Unit); ?></p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\quizres\resources\views/quiz/show.blade.php ENDPATH**/ ?>