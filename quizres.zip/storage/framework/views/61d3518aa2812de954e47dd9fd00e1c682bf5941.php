

<?php $__env->startSection('content'); ?>

<h1>My posts:</h1>
<p><?php echo e($post->quiz_name); ?></p>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\quizres\resources\views/post.blade.php ENDPATH**/ ?>