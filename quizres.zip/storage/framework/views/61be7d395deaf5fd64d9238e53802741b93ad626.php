

<?php $__env->startSection('content'); ?>
<div>
    <h1 class='text-center'>Перечень тестов(quiz):</h1>

    <table id="quiz-table" class="table table-bordered table-striped">
        <thead>
            <tr>
                <th style='display: none;'>quiz_id</th>
                <th>Название Quiz-а</th>
                <th>Код Quiz-а</th>
                <th>Программа</th>
                <th>Unit</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style='display: none;'><?php echo e($row['quiz_id']); ?></td>
            <td><?php echo e($row['quiz_name']); ?></td>
            <td><?php echo e($row['quiz_code']); ?></td>
            <td><?php echo e($row['Program']); ?></td>
            <td><?php echo e($row['Unit']); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\quizres\resources\views/quiz.blade.php ENDPATH**/ ?>