

<?php $__env->startSection('content'); ?>
<div class="container col-md-8">
    <h1 class='text-center mt-4'>Quiz:</h1>
    <div class='d-flex justify-content-around m-2 p-2 lead border border-info rounded-lg'>
        <div>
            <p>Название Quiz-а: </p>
            <p>Код Quiz-а: </p>
            <p>Программа: </p>
            <p>Unit: </p>
        </div>
        <div>
            <p><?php echo e($quiz->quiz_name); ?></p>
            <p><?php echo e($quiz->quiz_code); ?></p>
            <p><?php echo e($quiz->Program); ?></p>
            <p><?php echo e($quiz->Unit); ?></p>
        </div>
    </div>
    <a class="btn btn-outline-primary m-2" href="<?php echo e($quiz->path()); ?>/edit" role="button">Редактировать</a>
    <a class="btn btn-outline-secondary ml-4" href="/quizzes" role="button">&nbsp&nbsp Закрыть &nbsp&nbsp</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\laravel\resources\views/quiz/show.blade.php ENDPATH**/ ?>